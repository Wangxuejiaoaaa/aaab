package com.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;

@SuppressWarnings("rawtypes")
public class PublicCmd {
	/**
	 * 根据sql查询，返回一个字段
	 */
	public static String find_returnOne(String sql) {
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		ResultSet rs = null;
		String rstr = "-2";
		Statement stm = null;
		try {
			stm = con.createStatement();
			rs = stm.executeQuery(sql);
			if (rs.next()) {
				rstr = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rstr;
	}

	/**
	 * 根据sql查询，返回一个实体对象
	 */
	public static Hashtable find_OneObject(String sql) {
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		ResultSet rs = null;
		Statement stm = null;
		Hashtable<String, String> rstr = new Hashtable<String, String>();
		try {
			stm = con.createStatement();
			rs = stm.executeQuery(sql);
			// 数据结果字段
			while (rs.next()) {
				ResultSetMetaData rsm = rs.getMetaData();
				int rsmlength = rsm.getColumnCount();// 数据结果字段数量
				for (int column = 1; column <= rsmlength; column++) {
					String cname = rsm.getColumnName(column);// 获得字段名称
					String cnamevalue = String.valueOf(rs.getString(cname));
					if (cnamevalue == null) {
						cnamevalue = "";
					}
					rstr.put(cname.toUpperCase(), cnamevalue); // 赋值
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rstr;
	}

	/**
	 * 根据sql语句查询，返回实体类集
	 */
	@SuppressWarnings("unchecked")
	public static ArrayList find_allObject(String sql) {
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		ArrayList arr = new ArrayList();
		ResultSet rs = null;
		Statement stm = null;
		try {
			stm = con.createStatement();
			rs = stm.executeQuery(sql);
			// 数据结果字段
			while (rs.next()) {
				ResultSetMetaData rsm = rs.getMetaData();
				int rsmlength = rsm.getColumnCount();// 数据结果字段数量
				Hashtable<String, String> rstr = new Hashtable<String, String>();
				for (int column = 1; column <= rsmlength; column++) {
					String cname = rsm.getColumnName(column);// 获得字段名称
					String cnamevalue = String.valueOf(rs.getString(cname));
					if (cnamevalue == null) {
						cnamevalue = "";
					}
					rstr.put(cname.toUpperCase(), cnamevalue); // 赋值

				}
				arr.add(rstr);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return arr;
	}

	/**
	 * 根据id修改
	 */
	public static boolean update_byid(String sql, String id) {
		boolean flag = false;
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		PreparedStatement pstm = null;
		try {
			pstm = con.prepareStatement(sql);
			pstm.setString(1, id);
			if (pstm.executeUpdate() > 0) {
				flag = true;
			}
			// con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return flag;
	}

	/**
	 * 根据sql语句修改
	 */
	public static boolean update(String sql) {
		boolean flag = false;
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		PreparedStatement pstm = null;
		try {
			pstm = con.prepareStatement(sql);
			if (pstm.executeUpdate() > 0) {
				flag = true;
			}
			// con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return flag;
	}

	/**
	 * 根据sql语句删除数据
	 */
	public static boolean delete(String sql) {
		boolean flag = false;
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		PreparedStatement pstm = null;
		try {
			pstm = con.prepareStatement(sql);
			if (pstm.executeUpdate() != 1) {
			} else {
				flag = true;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		return flag;
	}

	/**
	 * 根据提供ht添加数据
	 */
	public static boolean insert_returnflag(Hashtable ht, String tablename) {
		boolean flag = false;
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		PreparedStatement pstm = null;
		String sql = "insert into " + tablename;
		String columns = "(";
		String values = "(";
		// 读取ht信息
		Enumeration e = ht.keys();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			if (!"".equals(ht.get(key)) && ht.get(key) != null) {
				columns = columns + key + ",";
				values = values + "'" + ht.get(key) + "',";
			}
		}
		columns = columns.substring(0, columns.length() - 1);
		values = values.substring(0, values.length() - 1);
		columns = columns + ")";
		values = values + ")";
		sql = sql + columns + "values" + values;
		if (!columns.equals("()") && !values.equals("()")) {
			try {
				pstm = con.prepareStatement(sql);
				if (pstm.executeUpdate() > 0) {
					flag = true;
				}
				// con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} finally {
				try {
					pstm.close();
					con.close();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		}
		return flag;
	}

	/**
	 * 根据提供ht添加数据 返回增加后的id
	 */
	public static String insert_returnnewid(Hashtable ht, String tablename,
			String seqname) {
		String id = "";
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		PreparedStatement pstm = null;
		String sql = "insert into " + tablename;
		String columns = "(";
		String values = "(";
		// 读取ht信息
		Enumeration e = ht.keys();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			if (!"".equals(ht.get(key)) && ht.get(key) != null) {
				columns = columns + key + ",";
				values = values + "'" + (String) ht.get(key) + "',";
			}
		}
		columns = columns.substring(0, columns.length() - 1);
		values = values.substring(0, values.length() - 1);
		columns = columns + ")";
		values = values + ")";
		sql = sql + columns + "values" + values;
		if (!columns.equals("()") && !values.equals("()")) {
			try {
				pstm = con.prepareStatement(sql);
				if (pstm.executeUpdate() > 0) {
					PreparedStatement pre2 = null;
					ResultSet rs = null;
					pre2 = con.prepareStatement("select " + seqname
							+ ".currval from dual");
					rs = pre2.executeQuery();
					if (rs.next()) {
						id = rs.getString(1);
					} else {
						id = "";
					}
				}
				// con.commit();
			} catch (SQLException e1) {
				e1.printStackTrace();
			} finally {
				try {
					pstm.close();
					con.close();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		}
		return id;
	}

	/**
	 * 根据提供ht添加数据 返回id
	 */
	public static String insert_returnid(Hashtable ht, String tablename) {
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String rstr = "-2";
		String sql = "insert into " + tablename;
		String columns = "(";
		String values = "(";
		// 读取ht信息
		Enumeration e = ht.keys();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			if (!"".equals(ht.get(key)) && ht.get(key) != null) {
				columns = columns + key + ",";
				values = values + "'" + ht.get(key) + "',";
			}
		}
		columns = columns.substring(0, columns.length() - 1);
		values = values.substring(0, values.length() - 1);
		columns = columns + ")";
		values = values + ")";
		sql = sql + columns + "values" + values;
		if (!columns.equals("()") && !values.equals("()")) {
			try {
				pstm = con.prepareStatement(sql,
						Statement.RETURN_GENERATED_KEYS);
				if (pstm.executeUpdate() > 0) {
					rs = pstm.getGeneratedKeys(); // 获取
					rs.next();
					int id = rs.getInt(1);
					rstr = "" + id;
					// rs = pstm.executeQuery("SELECT LAST_INSERT_ID()");
					// if (rs.next()) {
					// rstr = rs.getString(1);
					// }
				}
				// con.commit();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} finally {
				try {
					pstm.close();
					con.close();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		}
		return rstr;
	}

	/** 根据sql添加数据表 */
	public static boolean creat_Table(String sql) {
		boolean flag = false;
		DBConn dbConnection = new DBConn();
		Connection con = dbConnection.getConnection();
		PreparedStatement pstm = null;
		// sql = "create TABLE Person (LastName varchar,FirstName
		// varchar,Address varchar,Age int)";
		// sql = "create TABLE "+tablename+"(LastName varchar,FirstName
		// varchar,Address varchar,Age int)";
		try {
			pstm = con.prepareStatement(sql);
			if (pstm.execute()) {
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		return flag;
	}


	// 权限判断
	public static boolean checkqx(String qxs, String qx) {
		// 权限判断
		// String qx=(String)request.getSession().getAttribute("qx");
		boolean hasqx = false;
		String[] qxarr = qxs.split(",");
		for (int i = 0; i < qxarr.length; i++) {
			if (qx.equals(qxarr[i])) {
				hasqx = true;
				break;
			}
		}
		return hasqx;
	}

	// 过滤特殊字符
	public static String glstr1(String str) {
		// str = str.replace("'", "''");
		return str;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// cllc("tab_xmxx", "1", "");

	}
}
