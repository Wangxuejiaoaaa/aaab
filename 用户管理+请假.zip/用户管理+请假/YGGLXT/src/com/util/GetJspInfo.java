package com.util;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

public class GetJspInfo {

	/* 获得前台的变量信息 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static final Hashtable getRequestDataWithPrefixUnicode(
			String prefix, HttpServletRequest request) {
		Hashtable therequestdata = new Hashtable();
		Vector parameternames = getParameterNamesWithPrefix(prefix, request);
		if (parameternames != null && parameternames.size() > 0) {
			for (int i = 0; i < parameternames.size(); i++) {
				String name = String.valueOf(parameternames.get(i));
				String paraname = (new StringBuilder(String.valueOf(prefix)))
						.append(name).toString();// 变量名
				String parvalue = request.getParameter(paraname);
				parvalue = parvalue.replace("\\", "/");
				parvalue = parvalue.replace("'", "''");
				parvalue = parvalue.replace("\"", "”");
				therequestdata.put(name.toUpperCase(), parvalue);
			}
			return therequestdata;
		} else {
			return null;
		}
	}

	/* 获得前台变量名称 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static final Vector getParameterNamesWithPrefix(String prefix,
			HttpServletRequest request) {
		Enumeration names = request.getParameterNames();// 获得前台页面的变量名称
		Vector subname = new Vector();
		String value = "";
		while (names.hasMoreElements()) {
			String name = names.nextElement().toString();
			if (name.startsWith(prefix)) {
				value = name.substring(prefix.length(), name.length());
				subname.add(value);
			}
		}
		return subname;
	}

	/* 中文处理 */
	public static final String toUnicode(String str) {
		try {
			return new String(str.getBytes("8859_1"), "UTF-8");
		} catch (Exception e) {
			return str;
		}
	}

}
