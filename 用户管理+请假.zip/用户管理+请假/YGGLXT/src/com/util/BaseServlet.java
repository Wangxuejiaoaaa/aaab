package com.util;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings({ "unchecked", "serial", "rawtypes" })
/**
 * servlet基础类，不需要在web.xml中配置，新建servlet需要继承BaseServlet,而不是继承HttpServlet
 * 继承BaseServlet的类不能再有doget，dopost方法，否则后台报错
 */
public class BaseServlet extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String methodName = request.getParameter("action") != null ? request
				.getParameter("action") : "";

		Class clazz = this.getClass();
		try {
			Method method = clazz.getDeclaredMethod(methodName, new Class[] {
					HttpServletRequest.class, HttpServletResponse.class });

			method.invoke(this, new Object[] { request, response });

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
