package servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.TimeZone;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.BaseServlet;
import com.util.DateUtil;
import com.util.GetJspInfo;
import com.util.Page;
import com.util.PublicCmd;

import src.util.PublicUtil;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 请假管理
 * 
 * @author wzy
 */
@SuppressWarnings({ "serial", "rawtypes", "unused" })
public class QjglServlet extends BaseServlet {
	// 操作标志
	private String flag = "";

	// 请假信息
	public void find(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前登录请假名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		// 获取页面查询条件
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("find_qjgl_", request);
		// 获取排序条件
		String pxtj = "";
		String cxtj = "";
		if (ht != null) {
			String qjrqq = ht.get("QJRQQ") == null ? "" : (String) ht.get("QJRQQ");
			if (!"".equals(qjrqq)) {
				cxtj = cxtj + "&qjrqq=" + qjrqq;
				pxtj = pxtj + " and qjrq >= '" + qjrqq + "'";
			}

			String qjrqz = ht.get("QJRQZ") == null ? "" : (String) ht.get("QJRQZ");
			if (!"".equals(qjrqz)) {
				cxtj = cxtj + "&qjrqz=" + qjrqz;
				pxtj = pxtj + " and qjrq <= '" + qjrqz + "'";
			}
		} else {
			String qjrqq = request.getParameter("qjrqq") == null ? "" : request.getParameter("qjrqq");
			if (!"".equals(qjrqq)) {
				cxtj = cxtj + "&qjrqq=" + qjrqq;
				pxtj = pxtj + " and qjrq >= '" + qjrqq + "'";
			}

			String qjrqz = request.getParameter("qjrqz") == null ? "" : request.getParameter("qjrqz");
			if (!"".equals(qjrqz)) {
				cxtj = cxtj + "&qjrqz=" + qjrqz;
				pxtj = pxtj + " and qjrq <= '" + qjrqz + "'";
			}
		}

		String indexKey = "id";// 排序关键
		String sort = " asc ";
		// 查询信息
		String sql = "select a.*,b.xm as shrmc,"
				+ "case when shbz='O' then '审核中' else case when shbz='T' then '审核通过' else '审核未通过' end end as shxx "
				+ "from qjb a left join yhb b on a.shr=b.id where qjr=" + hasuser.get("ID") + pxtj;

		/* 分页 */
		String sql0 = "select count(1) from (" + sql + ") cona";
		int size = 0;
		if ("-2".equals(PublicCmd.find_returnOne(sql0))) {
			size = 0;
		} else {
			size = Integer.parseInt(PublicCmd.find_returnOne(sql0));
		}
		long curPage = 0l;
		if (null == request.getParameter("curPage") || "".equals(request.getParameter("curPage"))) {
			curPage = 1l;
		} else {
			curPage = Long.parseLong(request.getParameter("curPage"));
		}
		int pageSize = 8;

		String types = "mysql";
		sql = Page.getSql(sql, curPage, pageSize, indexKey, sort, types);
		String target = request.getContextPath() + "/servlet/QjglServlet?action=find&flag=" + flag + cxtj + "&";
		String linkStr = Page.getPagestr(size, pageSize, curPage, target);
		request.setAttribute("linkStr", linkStr);
		/* 分页 */
		ArrayList qjgl_arr = PublicCmd.find_allObject(sql);
		request.setAttribute("qjgl_arr", qjgl_arr);

		request.getRequestDispatcher("/qjgl.jsp").forward(request, response);
	}

	// 信息初始化跳转
	public void intxxedit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 当前登录请假名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		request.setAttribute("flag", flag);
		// String id = (String) request.getAttribute("ID");
		String id = request.getParameter("id") == null ? "" : request.getParameter("id");
		if (!"".equalsIgnoreCase(id)) {
			String sql = "select t.* from qjb t where  t.id=" + id;
			Hashtable ht = PublicCmd.find_OneObject(sql);
			request.setAttribute("rbht", ht);
		} else {
		}
		request.getRequestDispatcher("/qjedit.jsp").forward(request, response);
	}

	// 保存请假信息
	public void saveqjxx(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 当前登录请假名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		// 获取页面信息通过方法转成hashtable
		String id = request.getParameter("id");
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("up_qjxx_", request);
		if ("0".equals(id)) {
			String countsql = "select count(1) from qjb t where t.qjrq='" + ht.get("QJRQ")
					+ "' and (t.shbz='T' or t.shbz='O') and qjr=" + hasuser.get("ID");
			String co = PublicCmd.find_returnOne(countsql);
			if ("0".equals(co))// 请假日期不重复，可以注册
			{
				ht.put("QJR", hasuser.get("ID"));
				String now = PublicUtil.getDate("yyyy-MM-dd HH:mm:ss");
				ht.put("CZSJ", now);
				if (PublicCmd.insert_returnflag(ht, "qjb")) {
					response.setContentType("text/html;charset=utf-8");
					response.getWriter().print("<script type='text/javascript'>alert('请假成功');" + "location='"
							+ request.getContextPath() + "/qjgl.jsp?loadbz=load'</script>");
				} else {

					response.setContentType("text/html;charset=utf-8");
					response.getWriter()
							.print("<script type='text/javascript'>alert('请假失败，请重试');window.history.go(-1);</script>");
				}
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print("<script type='text/javascript'>alert('请假失败，" + ht.get("QJRQ")
						+ "已经请假了，请修改后重试');window.history.go(-1);</script>");
			}
		} else {
			String countsql = "select count(1) from qjb t where t.qjrq='" + ht.get("QJRQ")
					+ "' and (t.shbz='T' or t.shbz='O') and qjr=" + hasuser.get("ID") + " and id<>" + id;
			String co = PublicCmd.find_returnOne(countsql);
			if ("0".equals(co))// 请假日期不重复，可以注册
			{
				String now = PublicUtil.getDate("yyyy-MM-dd HH:mm:ss");
				String sql = "update qjb set qjrq='" + ht.get("QJRQ") + "',qjsy='" + ht.get("QJSY") + "',CZSJ='" + now
						+ "' ";
				sql = sql + " where id=" + id;
				String message = "";
				if (PublicCmd.update(sql)) {
					message = "修改成功！";
					response.setContentType("text/html;charset=utf-8");
					response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
							+ request.getContextPath() + "/qjgl.jsp?loadbz=load'</script>");
				} else {
					response.setContentType("text/html;charset=utf-8");
					response.getWriter()
							.print("<script type='text/javascript'>alert('修改失败，请重试');window.history.go(-1);</script>");
				}
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print("<script type='text/javascript'>alert('请假失败，" + ht.get("QJRQ")
						+ "已经请假了，请修改后重试');window.history.go(-1);</script>");
			}
		}
	}

	// 删除请假信息
	public void delxx(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 获取页面信息通过方法转成hashtable
		String id = request.getParameter("id");
		String updatesql = "";
		String sql = "delete from  qjb ";
		sql = sql + " where id=" + id;
		String message = "";
		if (PublicCmd.update(sql)) {
			message = "删除成功！";
			String usersql = "select * from qjb where id=" + id;// 查询sql语句
			Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据请假名称查询条数据
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
					+ request.getContextPath() + "/qjgl.jsp?loadbz=load'</script>");
		} else {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter()
					.print("<script type='text/javascript'>alert('删除失败，请重试');window.history.go(-1);</script>");
		}

	}

	// 请假审核
	public void qjsh(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前登录请假名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		// 获取页面查询条件
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("find_qjsh_", request);
		// 获取排序条件
		String pxtj = "";
		String cxtj = "";
		if (ht != null) {
			String qjrqq = ht.get("QJRQQ") == null ? "" : (String) ht.get("QJRQQ");
			if (!"".equals(qjrqq)) {
				cxtj = cxtj + "&qjrqq=" + qjrqq;
				pxtj = pxtj + " and qjrq >= '" + qjrqq + "'";
			}

			String qjrqz = ht.get("QJRQZ") == null ? "" : (String) ht.get("QJRQZ");
			if (!"".equals(qjrqz)) {
				cxtj = cxtj + "&qjrqz=" + qjrqz;
				pxtj = pxtj + " and qjrq <= '" + qjrqz + "'";
			}
		} else {
			String qjrqq = request.getParameter("qjrqq") == null ? "" : request.getParameter("qjrqq");
			if (!"".equals(qjrqq)) {
				cxtj = cxtj + "&qjrqq=" + qjrqq;
				pxtj = pxtj + " and qjrq >= '" + qjrqq + "'";
			}

			String qjrqz = request.getParameter("qjrqz") == null ? "" : request.getParameter("qjrqz");
			if (!"".equals(qjrqz)) {
				cxtj = cxtj + "&qjrqz=" + qjrqz;
				pxtj = pxtj + " and qjrq <= '" + qjrqz + "'";
			}
		}

		String indexKey = "id";// 排序关键
		String sort = " asc ";
		// 查询信息
		String sql = "select a.*,b.xm as shrmc,c.xm as qjrmc,"
				+ "case when shbz='O' then '审核中' else case when shbz='T' then '审核通过' else '审核未通过' end end as shxx,"
				+ "case when qjrq<=SUBSTR(now() FROM 1 FOR 10) then 'F' else 'T' end as yxbz "
				+ "from qjb a left join yhb b on a.shr=b.id left join yhb c on a.qjr=c.id  where qjr in (select id from yhb where bmid ="
				+ hasuser.get("BMID") + ") and 1=1 " + pxtj;
		/* 分页 */
		String sql0 = "select count(1) from (" + sql + ") cona";
		int size = 0;
		if ("-2".equals(PublicCmd.find_returnOne(sql0))) {
			size = 0;
		} else {
			size = Integer.parseInt(PublicCmd.find_returnOne(sql0));
		}
		long curPage = 0l;
		if (null == request.getParameter("curPage") || "".equals(request.getParameter("curPage"))) {
			curPage = 1l;
		} else {
			curPage = Long.parseLong(request.getParameter("curPage"));
		}
		int pageSize = 8;

		String types = "mysql";
		sql = Page.getSql(sql, curPage, pageSize, indexKey, sort, types);
		String target = request.getContextPath() + "/servlet/QjglServlet?action=qjsh&flag=" + flag + cxtj + "&";
		String linkStr = Page.getPagestr(size, pageSize, curPage, target);
		request.setAttribute("linkStr", linkStr);
		/* 分页 */
		ArrayList qjsh_arr = PublicCmd.find_allObject(sql);
		request.setAttribute("qjsh_arr", qjsh_arr);

		request.getRequestDispatcher("/qjsh.jsp").forward(request, response);
	}

	// 信息初始化跳转
	public void intsh(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前登录请假名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		request.setAttribute("flag", flag);
		// String id = (String) request.getAttribute("ID");
		String id = request.getParameter("id") == null ? "" : request.getParameter("id");
		if (!"".equalsIgnoreCase(id)) {
			String sql = "select t.* from qjb t where  t.id=" + id;
			Hashtable ht = PublicCmd.find_OneObject(sql);
			request.setAttribute("rbht", ht);
		} else {
		}
		request.getRequestDispatcher("/qjshedit.jsp").forward(request, response);
	}

	// 保存审核
	public void saveqjsh(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 当前登录请假名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		// 获取页面信息通过方法转成hashtable
		String id = request.getParameter("id");
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("up_qjsh_", request);
		if ("0".equals(id)) {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter()
					.print("<script type='text/javascript'>alert('审核失败，请刷新后重试');window.history.go(-1);</script>");
		} else {
			String now = PublicUtil.getDate("yyyy-MM-dd HH:mm:ss");
			String sql = "update qjb set shr=" + hasuser.get("ID") + ",shbz='" + ht.get("SHBZ") + "',shsj='" + now
					+ "',shyj='" + ht.get("SHYJ") + "' ";
			sql = sql + " where id=" + id;
			String message = "";
			if (PublicCmd.update(sql)) {
				message = "审核成功！";
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
						+ request.getContextPath() + "/qjsh.jsp?loadbz=load'</script>");
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter()
						.print("<script type='text/javascript'>alert('审核失败，请重试');window.history.go(-1);</script>");
			}
		}
	}
}
